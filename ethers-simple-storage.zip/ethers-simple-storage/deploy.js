const ethers = require("ethers");
// const { ethers } = require("ethers");
const { JsonRpcProvider } = require("ethers");
const fs = require("fs-extra");

async function main() {
    // compile them separately: 
    const provider = new JsonRpcProvider("http://127.0.0.1:7545");
    const wallet = new ethers.Wallet(
        "0xa36f928793df0de7f935a3b4f73ae60f9ea1cac9a2801bb90f6020de1e9dca80",
        provider
    );
    const abi = fs.readFileSync("./SimpleStorage_sol_SimpleStorage.abi", "utf8");
    const binary = fs.readFileSync("./SimpleStorage_sol_SimpleStorage.bin", "utf8");
    const contractFactory = new ethers.ContractFactory(abi, binary, wallet);

    console.log("Deploying, please wait...");
    const contract = await contractFactory.deploy();
    console.log("errorrrrr,  wait...");
    console.log(contract);

}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error)
        process.exit(1)
    })